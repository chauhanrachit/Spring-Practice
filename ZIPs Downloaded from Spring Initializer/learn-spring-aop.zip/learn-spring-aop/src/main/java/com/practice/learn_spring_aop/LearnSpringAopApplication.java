package com.practice.learn_spring_aop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LearnSpringAopApplication {

	public static void main(String[] args) {
		SpringApplication.run(LearnSpringAopApplication.class, args);
	}

}
