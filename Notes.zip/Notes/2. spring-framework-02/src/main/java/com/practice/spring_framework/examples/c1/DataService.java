package com.practice.spring_framework.examples.c1;

public interface DataService {
	int [] retreiveData() ;
}
