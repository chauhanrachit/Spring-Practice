package com.practice.springboot.learn_jpa_hibernate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearnJpaHibernateApplicationTests {

	@Test
	void contextLoads() {
	}

}
